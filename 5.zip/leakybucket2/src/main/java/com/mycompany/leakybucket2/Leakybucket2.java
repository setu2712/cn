/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.leakybucket2;

/**
 *
 * @author HP
 */
public class Leakybucket2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
